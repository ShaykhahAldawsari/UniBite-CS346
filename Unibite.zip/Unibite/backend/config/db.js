const { MongoClient } = require('mongodb');

const uri = 'your_mongodb_connection_uri';

let db;

const connectDB = async (callback) => {
    MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
        if (err) return console.error(err);
        db = client.db('unibite');
        callback();
    });
};

const getDB = () => db;

module.exports = { connectDB, getDB };
