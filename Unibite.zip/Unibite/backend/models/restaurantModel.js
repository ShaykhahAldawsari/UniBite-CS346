const { getDB } = require('../config/db');

const getRestaurants = async () => {
    const db = getDB();
    return await db.collection('restaurants').find().toArray();
};

module.exports = { getRestaurants };
