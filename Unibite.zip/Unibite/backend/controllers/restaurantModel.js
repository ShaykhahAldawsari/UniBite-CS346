const { getRestaurants } = require('../models/restaurantModel');

const fetchRestaurants = async (req, res) => {
    try {
        const restaurants = await getRestaurants();
        res.json(restaurants);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

module.exports = { fetchRestaurants };
