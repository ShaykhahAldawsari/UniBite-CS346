const express = require('express');
const { fetchRestaurants } = require('../controllers/restaurantController');
const router = express.Router();

router.get('/', fetchRestaurants);

module.exports = router;
